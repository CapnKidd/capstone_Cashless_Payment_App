class ImageConstant {
  static String imgNewlogo1 = 'assets/images/img_newlogo1.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
