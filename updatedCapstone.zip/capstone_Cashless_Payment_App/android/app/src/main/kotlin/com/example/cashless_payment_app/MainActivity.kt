package com.example.cashless_payment_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
